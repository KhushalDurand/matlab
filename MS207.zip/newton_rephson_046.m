% Q.2 newton rephson method
% let system of non-linea equation : x^3-2*y+x=0 && 2*y^3-x^2+y+1=0

clc;
clear;
f1 = @(x,y) x^3-2*y+x;
f2 = @(x,y) 2*y^3-x^2+y+1;

% forming A and B

f1_x =  @(x,y) 3*x^2+1;
f1_y =  @(x,y) -2;
f2_x =  @(x,y) -2*x;
f2_y=  @(x,y)6*y^2+1;


% let ig (x,y) = (0,0)

X = zeros(2,1);
n=length(X);

max_iter = 1000;
tol = 1e-9;

for i= 1:max_iter

    x = X(1);
    y = X(2);
    A = [f1_x(x,y) f1_y(x,y) ;f2_x(x,y)  f2_y(x,y)];
    B = [f1(x,y); f2(x,y)];
    if abs(B(1))<tol && abs(B(2))<tol
        fprintf("converged in %d iteration",i-1);
        break;
    end
    dx = A\(-B);
    X = X+dx;

end
X
