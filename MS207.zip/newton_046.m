function [yp1]= newton_046(x,y,xp)
      n = length(x);
      m = length(xp);
      D = zeros(n,n);
      D(:,1)=y;
      for j =2:n
          for i=1:n-j+1
              D(i,j)= (D(i+1,j-1)-D(i,j-1))/( x(i+j-1)-x(i) );
          end
      end
      yp1=zeros(m,1);
      for j = 1:m
          factor =1;
          for i=1:n-1
              factor=factor*(xp(j)-x(i));
              yp1(j)=yp1(j)+D(1,i+1)*factor;
          end
      end

end

