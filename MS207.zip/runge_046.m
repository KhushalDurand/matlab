% Q.3  cubic splines vs  newton indirect interpolation
clc;
clear;
x=linspace(-1,1,10)';
y=1./(1+25.*x.*x);

% interpolation point ( for plot ) 
xp = linspace(-1,1,1000)';
yp = 1./(1+25.*xp.*xp);
[yp1]=newton_046(x,y,xp);
[yp2]=cubic_046(x,y,xp);
figure
grid on
hold on
title("runge VS cubic vs NI interpolation")
plot(x,y,"*w")
plot(xp,yp,"-b","DisplayName",['runge plot'])
plot(xp,yp1,"-r","DisplayName",['newtons plot'])
plot(xp,yp2,"-g","DisplayName",['cubics plot'])
legend

% conclusion

% as we can see in plots the cubic interpolation plot is closer to runge plot
% as compared to newtons plot AND hence we can say cubic spline interpolation gives more accuracy