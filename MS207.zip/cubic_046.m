function [yp2]= cubic_046(x,y,xp)
      n = length(x);
      m = length(xp);
      h = diff(x);
     
      A=zeros(n,n);
      B=zeros(n,1);

      % natural spline boundary conditions
      A(1,1)=h(1);
      A(n,n)=h(n-1);
      B(1)=0;
      B(n)=0;     % no need to explicitly mention
      for i=2:n-1
          A(i,i-1)=h(i-1);
          A(i,i)=2*(h(i-1)+h(i));
          A(i,i+1)=h(i);
          term1= (y(i+1)-y(i))/(x(i+1)-x(i));
          term2= (y(i)-y(i-1))/(x(i)-x(i-1));
          B(i) = 3*(term1-term2);
      end
      c = A\B;
      a=y;
      b=zeros(n-1,1);
      d = zeros(n-1,1);
      for i=1:n-1
          d(i) = (c(i+1)-c(i))/(3*h(i));
          term1 = (y(i+1)-y(i))/(h(i));
          term2 = (h(i)/3)*(c(i+1)+2*c(i));
          b(i)=term1-term2;
      end

      yp2=zeros(m,1);
      for j = 1:m
          for i=1:n-1
              if xp(j)>=x(i) && xp(j)<x(i+1)
                  dx = xp(j)-x(i);
                  yp2(j)=a(i)+b(i)*dx+c(i)*dx^2+d(i)*dx^3;
              end
          end
      end
end