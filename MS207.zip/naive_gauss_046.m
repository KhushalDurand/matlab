% Q.1 naive gauss elimination
% let x1 = 1   x2=-1 x3=1

clc;
clear;
A = [10 3 1; 1 -10 3;2 -1 10];
B = [8;14;13];
n =length(B);
AUG = [A B];
x = zeros(n,1);

% forward elimination;

for i = 1:n-1
    m = AUG(i+1:n,i)/AUG(i,i);
    AUG(i+1:n,i+1:n+1)=AUG(i+1:n,i+1:n+1)-m*AUG(i,i+1:n+1);
end
% backward substitution
x(n)=AUG(n,n+1)/AUG(n,n);
for i=n-1:-1:1
    x(i)= (AUG(i,n+1)-AUG(i,i+1:n)*x(i+1:n))/AUG(i,i);
end
x